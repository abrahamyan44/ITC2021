----------Who are creators------

@Heghine, @Sepuh and @Vardges have created this project.

----------How to use it----------

*You can enter "make" to create bin directory for executable files.
*You can enter "make test" to create test_run directory, in which will be copied all the files from test directory, and
the whole project will work in current directory.
 *You can enter "make debug" for debuging your files from src directory.
 *You can enter "make release" or "make" for running files from src directory and adding them under bin directory. 
 *You can enter "make clean" for deleting all generated files and directories.
