#pragma once
#include <iostream>

typedef long long ll;

ll gcd(ll, ll);
