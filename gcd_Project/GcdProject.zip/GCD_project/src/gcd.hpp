#pragma once
#include <iostream>


void test();
int gcd(int,int);
