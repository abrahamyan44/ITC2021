#include <iostream>
#include <fstream>
#include "gcd.hpp"
using namespace std;

int gcd(int a , int b){
	if(a==b){
		return a;
	}
	if(a>b){
		return gcd(a-b,b);
	}
	
	return gcd(a,b-a);
}



void test(){
	std::fstream myFile;
	std::fstream outFile;
	outFile.open("../test/output.txt");
	int val;
	myFile.open("../test/input.txt");
	int a=0;
	int b=0;
	int count=0;

	while(myFile>>val ){
		if(count==1){
			b=val;
			count++;
			outFile<<gcd(a,b)<<"\n";
			a=0;
			b=0;
			count=0;

        }	
		else if(count==0){
			a=val;
			count++;
		}

	}
	outFile.close();
	myFile.close();

}

int main(){
	test();
	return 0;
}
