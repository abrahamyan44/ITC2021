const ROOT_PRODUCTS = document.getElementById('products');
const ROOT_HEADER = document.getElementById('header');
const ROOT_FOOTER = document.getElementById('footer');
const ROOT_CART = document.getElementById('cart');