// const CATALOG = [
//     {
//         id: "el1",
//         image:"./media/catalog/image1.jpg",
//         title:"Master and Margarita",
//         author: "Mikhail Bulgakov",
//     },   
//     {
//         id: "el2",
//         image:"./media/catalog/image2.jpg",
//         title:"The Great Gatsby",
//         author: "F. Scott Fitzgerald",
        
//     },
//     {
//         id: "el3",
//         image:"./media/catalog/image3.jpg",
//         title:"The Iliad and The Odyssey",
//         author: "Homer",
        
//     },    
//     {
//         id: "el4",
//         image:"./media/catalog/image4.jpeg",
//         title:"The Phantom of Opera",
//         author: "Gaston Leroux",
        
//     },
//     {
//         id: "el5",
//         image:"./media/catalog/image5.jpg",
//         title:"Crime and Punishment",
//         author: "Fyodor Dostoevsky",
        
//     },
//     {   id: "el6",
//         image:"./media/catalog/image6.jpg",
//         title:"The Brothers Karamazov",
//         author: "Fyodor Dostoevsky",
        
//     },
//     {
//         id: "el6",
//         image:"./media/catalog/image7.jpeg",
//         title:"The Idiot",
//         author: "Fyodor Dostoevsky",
        
//     },
//     {   
//       id: "el7",
//         image:"./media/catalog/image8.jpg",
//       title:"George Orwell",
//       author: "The Animal Farm",
      
//     },
//     {
//       id: "el8",
//         image:"./media/catalog/image9.jpg",
//       title:"The Alchemist",
//       author: "Paulo Coelho",
      
//     },
//     {
//       id: "el9",
//         image:"./media/catalog/image10.jpg",
//       title:"Pride and Prejudice",
//       author: "Jane Austin",
      
//     },
//     {
//       id: "el10",
//         image:"./media/catalog/image11.jpg",
//       title:"Little Women",
//       author: "Louisa May Alcott",
      
//     },
//     {
//       id: "el11",
//         image:"./media/catalog/image12.jpg",
//       title:"Leo Tolstoy",
//       author: "Anna Karenina",
      
//     },
//     {
//       id: "el12",
//         image:"./media/catalog/image13.jpeg",
//       title:"The Three Musketeers",
//       author: "Alexandre Dumas",
      
//     },
//     {
//       id: "el13",
//         image:"./media/catalog/image14.jpeg",
//       title:"The Last of Mohicans",
//       author: "James Fenimore Cooper",
      
//     },
//     {
//       id: "el14",
//         image:"./media/catalog/image15.jpg",
//       title:"The Wonderful Wizard of Oz",
//       author: "L. Frank Baum",
      
//     },
//     {
//       id: "el15",
//         image:"./media/catalog/image16.jpeg",
//       title:"Anna Karenina",
//       author: "Leo Tolstoy",
      
//     },
//     { 
//       id: "el16",
//         image:"./media/catalog/image17.jpeg",
//       title:"Of Human Bondage",
//       author: "W. Somerset Maugham",
      
//     },
//     { 
//       id: "el17",
//         image:"./media/catalog/image18.jpeg",
//       title:"Fathers and Sons",
//       author: "Ivan Turgenev",
      
//     },
//     { 
//       id: "el18",
//         image:"./media/catalog/image19.jpg",
//       title:"Lady Chatterley's Lover",
//       author: "D.H.Lawrence",
      
//     },
//     {
//       id: "el19",
//         image:"./media/catalog/image20.jpg",
//       title:"The Story of King Arthur & His Knights",
//       author: "Howard Pyle" ,
      
//     },   
//     { 
//       id: "el19",
//         image:"./media/catalog/image21.jpeg",
//       title:"Oliver Twist",
//       author: "Charles Dickens",
      
//     },
//     {
//       id: "el20",
//         image:"./media/catalog/image22.jpeg",
//       title:"Sister Carrie",
//       author: "Theodore Dreiser",
      
//     },
//     {
//       id: "el21",
//         image:"./media/catalog/image23.jpg",
//       title:"The Greek Myths",
//       author: "Caroline Hickey",
      
//     },
//     {
//       id: "el22",
//         image:"./media/catalog/image24.jpeg",
//       title:"The Forsyte Saga",
//       author: "John Galsworthy",
      
//      },
//      { 
//       id: "el23",
//         image:"./media/catalog/image25.jpeg",
//       title:"Gulliver's Travels",
//       author: "Jonathan Swift",
      
//      },
//      {
//       id: "el24",
//         image:"./media/catalog/image26.jpg",
//       title:"Pinocchio",
//       author: "Carlo Collodi",
      
//      },
//      {
//       id: "el25",
//         image:"./media/catalog/image27.jpeg",
//       title:"The picture of Dorian Gray",
//       author: "Oscar Wilde",
      
//      },
//      {
//       id: "el26",
//         image:"./media/catalog/image28.jpeg",
//       title:"Romeo and Juleiette",
//       author: "Shakespeare",
      
//      },
//      {
//       id: "el27",
//         image:"./media/catalog/image29.jpeg",
//       title:"Macbeth",
//       author: "Shakespeare",
      
//      },
//     {
//       id: "el28",
//         image:"./media/catalog/image30.jpeg",
//       title:"",
//       author: "",
      
//     }
// ];
