This project is created by VARDUHI SARGSYAN and ANNA HAKOBYAN

----------Commands---------

.$ make

.$ make clean

----------How to use it?----------

-To run the project use make command and pass two parameters.

      .first is length of the array which should be sorted

     .second is tests count which should be run on the same data (limited to 3)

-To clean all generated file do make clean.

---------The program description----------

When a program runs the output will be in a shell window. There will be a table with sorting algorithms name 

(Quick sort, Shell sort, Bubble sort, Heap sort and Merge sort) and minimum, maximum, and average results.
